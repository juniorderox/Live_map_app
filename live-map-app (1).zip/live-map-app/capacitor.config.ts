import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.livemap.user',
  appName: 'Live Map',
  webDir: 'dist/live-map-app/browser',
};

export default config;
