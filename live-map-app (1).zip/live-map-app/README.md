# Live Map — User App

This is the **user-facing app**. It has no way to create accounts — an admin
creates your login from the separate Admin App, using the same Firebase
project as this one. Once you have an email + password, log in here, click
**Share my location**, and your admin sees you live on their dashboard.

This app and the Admin App are two separate Angular projects that both point
at the same Firebase backend (same `environment.ts` config in both). Deploy
them to different URLs — this one can be public, the admin one shouldn't be.

## How it works

1. `GeolocationService` watches the browser's GPS.
2. `LiveTrackingService` throttles updates (every 3s) and writes them to
   Firestore at `trackers/{uid}`, keyed by your real Firebase Auth uid.
3. This app only ever subscribes to your own uid — you can't see anyone
   else's location here, only the admin app can, and only for its own users.

## Quick start

```bash
cd live-map-app
npm install
npm start
```

Open http://localhost:4200. You'll need an account first — created for you
in the Admin App (see that project's README).

> If `npm start` fails because the Angular CLI isn't installed globally, run
> `npx ng serve` instead, or `npm install -g @angular/cli` first.

## Setup (only needed once — shared with the Admin App)

Both apps use the exact same `environment.ts` values (Google Maps key +
Firebase config) and the same Firestore security rules. If you've already
set these up for the Admin App, just copy the same `src/environments/environment.ts`
and `src/index.html` script tag values into this project — don't create a
second Firebase project.

See the Admin App's README for the full first-time setup (Google Maps key,
Firebase Authentication + Firestore setup, security rules).

## Notes

- **Stale markers**: your tracker doc keeps its last known position even
  after you stop sharing, until you share again.
- **Cost**: Firestore writes are throttled to every 3s while sharing to keep
  usage low.

## Android app (background location tracking)

The web version above works great while the tab is open, but browsers
suspend GPS the moment the screen locks or the app backgrounds — that's a
hard browser limitation, not something fixable in web code. To get real
background tracking (screen locked, app minimized, still recording), this
project is also wired up as a Capacitor Android app using
`@capacitor-community/background-geolocation` (free, MIT-licensed).

The admin app is untouched — it stays a plain website, since it never
broadcasts location itself.

### One-time setup

1. **Install Android Studio**: https://developer.android.com/studio
   (this includes the Android SDK you'll need).
2. Install dependencies (if you haven't already):
   ```bash
   npm install
   ```
3. Add the Android platform to this project:
   ```bash
   npx cap add android
   ```
   This creates an `android/` folder — a full native Android project.

### Every time you change the app's code

```bash
npm run cap:sync
```
This rebuilds the Angular app and copies it into the native Android
project. Run this after any code change before rebuilding the APK.

### Building the APK

```bash
npx cap open android
```
This opens the project in Android Studio. Once it finishes indexing:

- **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- Wait for it to finish — click "locate" on the notification that appears,
  or find it manually at `android/app/build/outputs/apk/debug/app-debug.apk`

That `.apk` file is what you send to a phone (email it, upload it
somewhere, plug the phone in via USB and copy it over — any method works).
On the phone, opening the file will prompt to enable "Install from unknown
sources" for that source — approve it, then install normally.

### First run on a device

The app will prompt for location permission — on Android 10+, background
tracking requires "Allow all the time," not just "While using the app."
The prompt sequence usually asks for foreground access first, then a
second prompt for background access — approve both. While actively
sharing, Android will show a persistent notification ("Sharing your
location") — this is required by Android for any app doing background
location tracking, not something this app added unnecessarily; it can't
be hidden without breaking Android's transparency requirements.

### Notes

- This targets **Android only** for now. iOS is possible with the same
  plugin, but requires a Mac + Xcode + a paid ($99/year) Apple Developer
  account to install on a real device beyond your own — a hard requirement
  from Apple, not a limitation of this setup.
- Debug APKs (built as above) are fine for personal testing but are
  unsigned and will show a Play Protect warning on install — expected for
  now. A signed release build is a further step if you want to distribute
  this more broadly later.

## Native background tracking (Telegram-style reliability)

This app now uses a genuinely different architecture from a typical
Capacitor app for background location: instead of the native GPS service
handing data to JavaScript (which Android can throttle while the screen is
locked), a real Android foreground service — written in Java, running
independently of the WebView — talks to Firestore **directly**. This is
the same fundamental approach apps like Telegram use for reliable live
location sharing.

- `android/app/src/main/java/com/livemap/user/LocationTrackingService.java`
  — the foreground service. Gets GPS fixes via Android's
  FusedLocationProviderClient and writes straight to Firestore using the
  native Android Firebase SDK — no dependency on the JS layer being awake.
- `android/app/src/main/java/com/livemap/user/NativeTrackingPlugin.java`
  — the bridge JS calls into (`start`/`stop`), handling the permission
  request flow (foreground location → background location → notifications).
- Login now goes through `@capacitor-firebase/authentication` instead of
  calling the JS Firebase SDK directly. This matters because the native
  service needs its *own* signed-in Firebase Auth session (separate storage
  from the JS SDK) to pass Firestore's security rules — this plugin keeps
  both in sync automatically.
- The web version (`livemap2user.web.app`) is untouched and still works
  exactly as before — this new native path only applies inside the actual
  installed Android app.

### One-time setup: register an Android app in Firebase

The native Firebase SDK needs a `google-services.json` config file, which
requires registering an Android app (not just a web app) in your Firebase
project — a step we haven't needed until now.

1. Firebase Console → your `livemap2` project → Project settings (gear
   icon) → scroll to "Your apps" → click **Add app** → select **Android**.
2. **Android package name**: enter exactly `com.livemap.user` (must match
   exactly — this is the app's applicationId).
3. App nickname: anything, e.g. "Live Map Android".
4. Skip the SHA-1 field for now (only needed for Google Sign-In, which
   this app doesn't use).
5. Click **Register app**, then **download `google-services.json`**.
6. Place that file at `android/app/google-services.json` in this project
   (same folder as `android/app/build.gradle`).

Without this file, the native Firebase SDK won't initialize and the app
will crash on launch — this step isn't optional.

### Building

Same as before, but note the `android/` folder is now included in this
zip already (with the custom native files above) — **don't run
`npx cap add android` again**, it would prompt to overwrite these files.

```bash
npm install
```

Then add `google-services.json` as described above, then:

```bash
npx cap sync android
npx cap open android
```

In Android Studio: **Build → Generate App Bundles or APKs → Generate APKs**.

### What to expect on first launch

Tapping "Share my location" for the first time triggers three permission
prompts in sequence:
1. **Location** (foreground) — required, the app can't function without it.
2. **Location, all the time** (background) — required for tracking to
   survive the screen locking. If denied, the app still works while open,
   it just won't track with the screen off.
3. **Notifications** — required by Android for any app running a
   background location service; this is what shows the persistent
   "Sharing your location" notification. Android may kill the service
   without it.

### Known limitations, honestly

- This is real native Android development layered onto a Capacitor app —
  a meaningfully more complex and more fragile setup than the rest of this
  project. Expect to need debugging iteration getting the Gradle
  build/permissions fully working on a real device, similar in spirit to
  (though more involved than) the debugging done for the JS/web side.
- `google-services.json` is specific to the `com.livemap.user` package
  name — if you ever change the app's applicationId, you'll need to
  re-register and re-download it.
- Still phone-dependent for the most aggressive battery managers (Xiaomi,
  Oppo, etc.) — a true foreground service is far more resistant to being
  killed than the previous JS-mediated approach, but Android's battery
  optimization settings still matter and should be set to "Unrestricted"
  as before.
