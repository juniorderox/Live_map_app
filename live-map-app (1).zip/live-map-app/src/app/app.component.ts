import { Component, inject, OnInit } from '@angular/core';
import { AuthService } from './services/auth.service';
import { ScreenWakeService } from './services/screen-wake.service';
import { LoginComponent } from './components/login/login.component';
import { UserMapComponent } from './components/user-map/user-map.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [LoginComponent, UserMapComponent],
  template: `
    @if (auth.loading()) {
      <p class="loading">Loading...</p>
    } @else if (!auth.firebaseUser()) {
      <app-login />
    } @else if (auth.profile()?.role === 'user') {
      <app-user-map />
    } @else {
      <p class="loading">
        This account isn't set up as a user. If you're an admin, use the
        admin app instead.
        <br /><br />
        <button (click)="auth.logout()">Log out</button>
      </p>
    }
  `,
  styles: [`
    .loading { text-align: center; margin-top: 4rem; font-family: system-ui, sans-serif; color: #666; }
    button { padding: 0.5rem 1rem; border-radius: 6px; border: 1px solid #ccc; background: #fff; cursor: pointer; }
  `],
})
export class AppComponent implements OnInit {
  protected auth = inject(AuthService);
  private screenWake = inject(ScreenWakeService);

  ngOnInit(): void {
    // Keeps the screen from dimming/locking for as long as the app is
    // open — not just while actively sharing. Worth knowing: this does
    // increase battery drain compared to letting the screen sleep normally.
    this.screenWake.enable();
  }
}
