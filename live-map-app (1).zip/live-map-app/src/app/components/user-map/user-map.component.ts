import { Component, inject, signal, computed, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService, AppUserProfile } from '../../services/auth.service';
import { GeolocationService } from '../../services/geolocation.service';
import { LiveTrackingService } from '../../services/live-tracking.service';
import { GeocodingService } from '../../services/geocoding.service';
import { TrackerMapComponent } from '../tracker-map/tracker-map.component';

@Component({
  selector: 'app-user-map',
  standalone: true,
  imports: [CommonModule, TrackerMapComponent],
  template: `
    <div class="user-shell">
      <header>
        <h1>{{ auth.profile()?.label || 'My location' }}</h1>
        <button (click)="auth.logout()">Log out</button>
      </header>

      <div class="toolbar">
        <button (click)="toggleBroadcast()">
          {{ isBroadcasting() ? 'Stop sharing my location' : 'Share my location' }}
        </button>
        <button (click)="centerOnMe()">Center on me</button>
      </div>

      @if (geo.error()) {
        <div class="error-banner">{{ geo.error() }}</div>
      }

      @if (isBroadcasting() && !isOnline()) {
        <div class="offline-banner">
          You're offline — your location is still being recorded and will sync automatically once you're back online.
        </div>
      }

      @if (isBroadcasting()) {
        <div class="status-line">
          @if (myAddress()) {
            <span>📍 {{ myAddress() }}</span>
          }
          @if (mySpeed(); as speed) {
            <span class="speed">{{ speed }}</span>
          }
        </div>
      }

      <app-tracker-map [trackers]="trackerList()" [manualCenter]="manualCenter()" />
    </div>
  `,
  styles: [`
    .user-shell { max-width: 960px; margin: 0 auto; padding: 1.5rem; font-family: system-ui, sans-serif; display: flex; flex-direction: column; gap: 1rem; }
    header { display: flex; justify-content: space-between; align-items: center; }
    h1 { font-size: 1.25rem; margin: 0; }
    .toolbar { display: flex; gap: 0.5rem; }
    .toolbar button {
      padding: 0.5rem 1rem;
      border-radius: 6px;
      border: 1px solid #ccc;
      background: #fff;
      cursor: pointer;
    }
    .status-line { display: flex; gap: 1rem; font-size: 0.85rem; color: #444; }
    .speed { color: #666; }
    .error-banner {
      background: #fee2e2;
      color: #991b1b;
      padding: 0.5rem 0.75rem;
      border-radius: 6px;
      font-size: 0.85rem;
    }
    .offline-banner {
      background: #fef3c7;
      color: #92400e;
      padding: 0.5rem 0.75rem;
      border-radius: 6px;
      font-size: 0.85rem;
    }
  `],
})
export class UserMapComponent implements OnInit, OnDestroy {
  protected auth = inject(AuthService);
  protected geo = inject(GeolocationService);
  protected tracking = inject(LiveTrackingService);
  protected geocoding = inject(GeocodingService);

  protected readonly isBroadcasting = computed(() => this.tracking.isBroadcastingSignal());
  protected readonly trackerList = computed(() => Array.from(this.tracking.entities().values()));
  protected readonly manualCenter = signal<google.maps.LatLngLiteral | null>(null);
  protected readonly myAddress = signal<string | null>(null);
  protected readonly isOnline = signal(navigator.onLine);

  private addressRefreshTimer: ReturnType<typeof setInterval> | null = null;
  private readonly handleOnline = () => this.isOnline.set(true);
  private readonly handleOffline = () => this.isOnline.set(false);

  ngOnInit(): void {
    const uid = this.auth.firebaseUser()?.uid;
    if (uid) {
      this.tracking.subscribeToUids([uid]);
    }
    window.addEventListener('online', this.handleOnline);
    window.addEventListener('offline', this.handleOffline);
    this.resumeSharingIfPersisted();
  }

  ngOnDestroy(): void {
    this.tracking.unsubscribe();
    this.geo.stopCompass();
    if (this.addressRefreshTimer) clearInterval(this.addressRefreshTimer);
    window.removeEventListener('online', this.handleOnline);
    window.removeEventListener('offline', this.handleOffline);
  }

  async toggleBroadcast(): Promise<void> {
    const profile = this.auth.profile();
    if (!profile) return;

    if (this.isBroadcasting()) {
      this.tracking.stopBroadcasting();
      this.geo.stopCompass();
      if (this.addressRefreshTimer) {
        clearInterval(this.addressRefreshTimer);
        this.addressRefreshTimer = null;
      }
      this.myAddress.set(null);
    } else {
      await this.startSharing(profile.uid, profile.label || profile.email);
    }
  }

  private async startSharing(uid: string, label: string): Promise<void> {
    const granted = await this.geo.requestCompassPermission();
    if (granted) this.geo.startCompass();
    await this.tracking.startBroadcasting(uid, label);

    // Refresh the displayed address every 30s while sharing — frequent
    // enough to stay current, infrequent enough to keep Geocoding API
    // usage cheap.
    this.refreshMyAddress();
    if (this.addressRefreshTimer) clearInterval(this.addressRefreshTimer);
    this.addressRefreshTimer = setInterval(() => this.refreshMyAddress(), 30000);
  }

  /**
   * On app launch, checks whether the user was sharing when the app was
   * last closed (persisted to the phone's storage, not just in-memory) and
   * automatically resumes — without this, Android reclaiming the app's
   * memory after switching apps would silently turn sharing off, and the
   * person would have no idea until someone tells them their location
   * stopped updating.
   */
  private async resumeSharingIfPersisted(): Promise<void> {
    const profile = this.auth.profile() ?? (await this.waitForProfile());
    if (!profile) return;

    const intent = await this.tracking.getPersistedSharingIntent();
    if (intent && intent.uid === profile.uid && !this.isBroadcasting()) {
      await this.startSharing(profile.uid, intent.label);
    }
  }

  /** Auth profile may not have resolved yet on first launch — wait briefly for it. */
  private waitForProfile(): Promise<AppUserProfile | null> {
    return new Promise((resolve) => {
      let attempts = 0;
      const check = () => {
        const profile = this.auth.profile();
        if (profile || attempts > 20) {
          resolve(profile);
        } else {
          attempts++;
          setTimeout(check, 100);
        }
      };
      check();
    });
  }

  private refreshMyAddress(): void {
    const uid = this.auth.firebaseUser()?.uid;
    if (!uid) return;
    const entity = this.tracking.entities().get(uid);
    if (!entity) return;
    this.geocoding.reverseGeocode(entity.lat, entity.lng).then((address) => {
      this.myAddress.set(address);
    });
  }

  /** My current speed in km/h, or null if stationary/unknown. */
  mySpeed(): string | null {
    const uid = this.auth.firebaseUser()?.uid;
    if (!uid) return null;
    const entity = this.tracking.entities().get(uid);
    if (!entity || entity.speed == null) return null;
    const kmh = entity.speed * 3.6;
    if (kmh < 1) return null;
    return `${kmh.toFixed(0)} km/h`;
  }

  centerOnMe(): void {
    this.geo.getCurrentPosition()
      .then((pos) => {
        this.manualCenter.set({ lat: pos.lat, lng: pos.lng });
      })
      .catch((err) => {
        this.geo.setError(err.message ?? 'Could not get your current location.');
      });
  }
}
