import { Injectable, signal, effect, inject } from '@angular/core';
import { Preferences } from '@capacitor/preferences';
import {
  Firestore,
  doc,
  setDoc,
  addDoc,
  getDocs,
  writeBatch,
  serverTimestamp,
  collection,
  query,
  where,
  orderBy,
  limitToLast,
  documentId,
  onSnapshot,
  Unsubscribe,
} from '@angular/fire/firestore';
import { GeolocationService, GeoPosition } from './geolocation.service';

const SHARING_INTENT_KEY = 'liveMap.sharingIntent';

export interface TrackedEntity {
  id: string;
  label: string;
  lat: number;
  lng: number;
  heading: number | null;
  speed: number | null;
  updatedAt: number;
  /** False once the user has explicitly stopped sharing — marker stays at last known position. */
  online: boolean;
}

export interface HistoryPoint {
  lat: number;
  lng: number;
  /** Client-side capture time, not server time — see note in maybePush(). */
  timestamp: number;
  /** True if the device had no network connection at the moment this point was captured. */
  offline: boolean;
}

/**
 * Syncs the local device's position to Firestore ("trackers/{uid}", keyed by
 * the real Firebase Auth uid) and subscribes to a specific set of uids for a
 * live multi-marker map (e.g. the users an admin manages). Also records a
 * breadcrumb trail to "trackers/{uid}/history" so past routes — including
 * ones traveled while offline — can be viewed later.
 *
 * Firestore doc shape:
 *   trackers/{uid} = { label, lat, lng, heading, speed, online, updatedAt }
 *   trackers/{uid}/history/{autoId} = { lat, lng, timestamp, offline }
 */
@Injectable({ providedIn: 'root' })
export class LiveTrackingService {
  private firestore = inject(Firestore);
  private geo = inject(GeolocationService);

  private trackerId: string | null = null;
  private trackerLabel = 'Unnamed';
  private unsubscribeAll: Unsubscribe | null = null;
  private lastPushed = 0;
  private readonly pushIntervalMs = 3000; // throttle current-position writes

  // History points are written less often than position updates, to keep
  // Firestore write volume (and cost) reasonable over a long sharing session.
  private lastHistoryPushed = 0;
  private readonly historyPushIntervalMs = 8000;

  /** Live map of all currently-subscribed trackers, keyed by uid. */
  readonly entities = signal<Map<string, TrackedEntity>>(new Map());

  /**
   * Fires whenever a subscribed user transitions from online to offline —
   * i.e. they just stopped sharing. Consumers (e.g. an admin dashboard) can
   * use this to show a toast/notification. Each event includes the uid,
   * label, and timestamp; consumers are expected to prune old entries.
   */
  readonly offlineEvents = signal<{ uid: string; label: string; at: number }[]>([]);
  private readonly previousOnline = new Map<string, boolean>();

  /** Breadcrumb trail for whichever uid is currently subscribed via subscribeToHistory(). */
  readonly historyPoints = signal<HistoryPoint[]>([]);
  private historyUnsub: Unsubscribe | null = null;

  /** Whether broadcasting is currently active — set locally on start/stop for immediate UI feedback. */
  readonly isBroadcastingSignal = signal(false);

  constructor() {
    // Whenever local position changes, push it upstream (throttled).
    effect(() => {
      const pos = this.geo.position();
      if (pos && this.trackerId) {
        this.maybePush(pos);
      }
    });
  }

  /** Start broadcasting this device's position under the given uid/label. */
  startBroadcasting(uid: string, label: string): void {
    this.trackerId = uid;
    this.trackerLabel = label;
    this.geo.startWatching();
    this.isBroadcastingSignal.set(true);

    // Persist the intent to keep sharing so it survives the app being
    // switched away from, backgrounded, or even killed by the OS and
    // relaunched — without this, "Share my location" would silently reset
    // to off any time Android reclaims the app's memory, forcing the user
    // to notice and manually turn it back on.
    Preferences.set({
      key: SHARING_INTENT_KEY,
      value: JSON.stringify({ uid, label }),
    }).catch(() => {
      // Best-effort — if this fails, sharing still works for the current
      // session, it just won't auto-resume after a restart.
    });
  }

  /** Stop broadcasting and explicitly mark this tracker offline in Firestore. */
  stopBroadcasting(): void {
    if (this.trackerId) {
      const ref = doc(this.firestore, 'trackers', this.trackerId);
      setDoc(ref, { online: false, updatedAt: serverTimestamp() }, { merge: true }).catch(
        () => {
          // Best-effort — if this fails (e.g. offline), the doc just keeps its last state.
        }
      );
    }
    this.trackerId = null;
    this.geo.stopWatching();
    this.isBroadcastingSignal.set(false);
    Preferences.remove({ key: SHARING_INTENT_KEY }).catch(() => {});
  }

  /**
   * Checks whether the user was sharing when the app last closed, so the
   * caller (e.g. UserMapComponent on launch) can automatically resume
   * sharing instead of requiring a manual tap on "Share my location" every
   * time Android restarts the app after backgrounding it.
   */
  async getPersistedSharingIntent(): Promise<{ uid: string; label: string } | null> {
    try {
      const result = await Preferences.get({ key: SHARING_INTENT_KEY });
      if (!result.value) return null;
      return JSON.parse(result.value);
    } catch {
      return null;
    }
  }

  /**
   * Subscribe to a specific set of uids (e.g. an admin's managed users, or
   * just your own uid). Replaces any previous subscription. Firestore's
   * 'in' operator supports at most 10 values per query, so larger lists are
   * chunked automatically.
   */
  subscribeToUids(uids: string[]): void {
    this.unsubscribeAll?.();
    this.entities.set(new Map());
    if (uids.length === 0) return;

    const chunks: string[][] = [];
    for (let i = 0; i < uids.length; i += 10) {
      chunks.push(uids.slice(i, i + 10));
    }

    const unsubs: Unsubscribe[] = chunks.map((chunk) => {
      const q = query(
        collection(this.firestore, 'trackers'),
        where(documentId(), 'in', chunk)
      );
      return onSnapshot(q, (snapshot) => {
        const next = new Map(this.entities());
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as any;
          const uid = docSnap.id;
          const online = data.online ?? true; // default true for older docs written before this field existed

          // Detect an online -> offline transition and record it as an event.
          // previousOnline persists across resubscriptions for the service's
          // lifetime, so this only fires on a genuine live transition, not
          // just because we started watching someone already offline.
          const wasOnline = this.previousOnline.get(uid);
          if (wasOnline === true && online === false) {
            this.offlineEvents.update((events) => [
              ...events,
              { uid, label: data.label ?? uid, at: Date.now() },
            ]);
          }
          this.previousOnline.set(uid, online);

          next.set(uid, {
            id: uid,
            label: data.label ?? uid,
            lat: data.lat,
            lng: data.lng,
            heading: data.heading ?? null,
            speed: data.speed ?? null,
            updatedAt: data.updatedAt?.toMillis?.() ?? Date.now(),
            online,
          });
        });
        this.entities.set(next);
      });
    });

    this.unsubscribeAll = () => unsubs.forEach((u) => u());
  }

  unsubscribe(): void {
    this.unsubscribeAll?.();
    this.unsubscribeAll = null;
  }

  /**
   * Load and live-follow a single user's breadcrumb trail. Call when a user
   * is selected in the UI; call unsubscribeHistory() when deselected.
   * Limited to the most recent 500 points to keep the read bounded.
   */
  subscribeToHistory(uid: string): void {
    this.unsubscribeHistory();
    const q = query(
      collection(this.firestore, 'trackers', uid, 'history'),
      orderBy('timestamp'),
      limitToLast(500)
    );
    this.historyUnsub = onSnapshot(q, (snapshot) => {
      const points: HistoryPoint[] = snapshot.docs.map((d) => {
        const data = d.data() as any;
        return {
          lat: data.lat,
          lng: data.lng,
          timestamp: data.timestamp,
          offline: data.offline === true,
        };
      });
      this.historyPoints.set(points);
    });
  }

  unsubscribeHistory(): void {
    this.historyUnsub?.();
    this.historyUnsub = null;
    this.historyPoints.set([]);
  }

  /**
   * Permanently deletes every breadcrumb point for this user's trail.
   * The map's trail lines disappear immediately (we clear the local signal
   * right away rather than waiting on the delete + snapshot round-trip),
   * and new points start accumulating fresh from the next position update.
   * Batched in chunks of 500 (Firestore's per-batch write limit).
   */
  async clearHistory(uid: string): Promise<void> {
    const historyRef = collection(this.firestore, 'trackers', uid, 'history');
    const snap = await getDocs(historyRef);

    const docs = snap.docs;
    for (let i = 0; i < docs.length; i += 500) {
      const batch = writeBatch(this.firestore);
      docs.slice(i, i + 500).forEach((d) => batch.delete(d.ref));
      await batch.commit();
    }

    this.historyPoints.set([]);
  }

  private async maybePush(pos: GeoPosition): Promise<void> {
    const now = Date.now();
    if (now - this.lastPushed < this.pushIntervalMs) return;
    this.lastPushed = now;

    if (!this.trackerId) return;
    const ref = doc(this.firestore, 'trackers', this.trackerId);
    await setDoc(
      ref,
      {
        label: this.trackerLabel,
        lat: pos.lat,
        lng: pos.lng,
        // Prefer compass heading (works while stationary) over GPS heading
        // (only updates while moving).
        heading: this.geo.effectiveHeading() ?? pos.heading,
        speed: pos.speed,
        online: true,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );

    // Separately (and less often), append a breadcrumb point. Uses
    // Date.now() rather than serverTimestamp() deliberately: if this write
    // is queued offline (Firestore's offline persistence), serverTimestamp()
    // would resolve to whenever the write actually reaches the server after
    // reconnecting — losing the real capture time. A client timestamp keeps
    // the trail's chronology accurate even for points recorded offline.
    if (now - this.lastHistoryPushed >= this.historyPushIntervalMs) {
      this.lastHistoryPushed = now;
      const historyRef = collection(this.firestore, 'trackers', this.trackerId, 'history');
      addDoc(historyRef, {
        lat: pos.lat,
        lng: pos.lng,
        timestamp: now,
        offline: !navigator.onLine,
      }).catch(() => {
        // Best-effort — Firestore's offline queue handles the retry when
        // this fails purely due to being offline; a real failure just drops
        // this one breadcrumb point, which is an acceptable tradeoff.
      });
    }
  }
}
