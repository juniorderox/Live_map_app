import { Injectable, inject, signal } from '@angular/core';
import {
  Auth,
  authState,
  signInWithEmailAndPassword,
  signOut as fbSignOut,
  User,
} from '@angular/fire/auth';
import { Firestore, doc, getDoc } from '@angular/fire/firestore';

export interface AppUserProfile {
  uid: string;
  email: string;
  role: 'admin' | 'user';
  label?: string;
  ownerAdminId?: string | null;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private auth = inject(Auth);
  private firestore = inject(Firestore);

  readonly firebaseUser = signal<User | null>(null);
  readonly profile = signal<AppUserProfile | null>(null);
  readonly loading = signal(true);

  constructor() {
    authState(this.auth).subscribe(async (user) => {
      this.firebaseUser.set(user);
      if (user) {
        const snap = await getDoc(doc(this.firestore, 'users', user.uid));
        this.profile.set(snap.exists() ? ({ uid: user.uid, ...(snap.data() as any) }) : null);
      } else {
        this.profile.set(null);
      }
      this.loading.set(false);
    });
  }

  async login(email: string, password: string): Promise<void> {
    await signInWithEmailAndPassword(this.auth, email, password);
  }

  async logout(): Promise<void> {
    await fbSignOut(this.auth);
  }
}
