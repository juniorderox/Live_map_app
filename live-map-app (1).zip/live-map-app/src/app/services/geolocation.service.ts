import { Injectable, signal, computed } from '@angular/core';
import { Capacitor, registerPlugin } from '@capacitor/core';

export interface GeoPosition {
  lat: number;
  lng: number;
  accuracy: number;
  heading: number | null;
  speed: number | null;
  timestamp: number;
}

/**
 * Minimal typing for @capacitor-community/background-geolocation — only the
 * methods this service actually uses.
 */
interface BackgroundGeolocationPlugin {
  addWatcher(
    options: {
      backgroundMessage?: string;
      backgroundTitle?: string;
      requestPermissions?: boolean;
      stale?: boolean;
      distanceFilter?: number;
    },
    callback: (location: any, error: any) => void
  ): Promise<string>;
  removeWatcher(options: { id: string }): Promise<void>;
}

const BackgroundGeolocation = registerPlugin<BackgroundGeolocationPlugin>(
  'BackgroundGeolocation'
);

/**
 * Wraps location tracking in a signal-based service. On the web (browser),
 * uses the standard Geolocation API — which stops once the tab backgrounds
 * or the screen locks, a hard browser limitation. When running as the
 * Capacitor Android app, uses @capacitor-community/background-geolocation
 * instead, which requests real OS-level "background location" permission
 * and keeps reporting position even with the screen locked or the app
 * backgrounded (shows a persistent notification while doing so, an Android
 * requirement so the user always knows tracking is active).
 */
@Injectable({ providedIn: 'root' })
export class GeolocationService {
  private readonly _position = signal<GeoPosition | null>(null);
  private readonly _error = signal<string | null>(null);
  private readonly _isWatching = signal(false);

  private webWatchId: number | null = null;
  private nativeWatcherId: string | null = null;

  readonly position = this._position.asReadonly();
  readonly error = this._error.asReadonly();
  readonly isWatching = this._isWatching.asReadonly();
  readonly hasFix = computed(() => this._position() !== null);

  // --- Compass heading (device orientation) ---
  private readonly _compassHeading = signal<number | null>(null);
  readonly compassHeading = this._compassHeading.asReadonly();
  readonly effectiveHeading = computed(
    () => this._compassHeading() ?? this._position()?.heading ?? null
  );

  private readonly orientationHandler = (event: DeviceOrientationEvent) => {
    const anyEvent = event as any;
    if (typeof anyEvent.webkitCompassHeading === 'number') {
      this._compassHeading.set(anyEvent.webkitCompassHeading);
    } else if (event.alpha !== null) {
      this._compassHeading.set(360 - event.alpha);
    }
  };

  async requestCompassPermission(): Promise<boolean> {
    const DOE: any = (window as any).DeviceOrientationEvent;
    if (DOE && typeof DOE.requestPermission === 'function') {
      try {
        const result = await DOE.requestPermission();
        return result === 'granted';
      } catch {
        return false;
      }
    }
    return true;
  }

  startCompass(): void {
    const win = window as any;
    if ('ondeviceorientationabsolute' in window) {
      win.addEventListener('deviceorientationabsolute', this.orientationHandler, true);
    } else if ('ondeviceorientation' in window) {
      win.addEventListener('deviceorientation', this.orientationHandler, true);
    }
  }

  stopCompass(): void {
    const win = window as any;
    win.removeEventListener('deviceorientationabsolute', this.orientationHandler, true);
    win.removeEventListener('deviceorientation', this.orientationHandler, true);
    this._compassHeading.set(null);
  }

  async startWatching(): Promise<void> {
    if (this.webWatchId !== null || this.nativeWatcherId !== null) return;

    if (Capacitor.isNativePlatform()) {
      this._isWatching.set(true);
      try {
        this.nativeWatcherId = await BackgroundGeolocation.addWatcher(
          {
            backgroundTitle: 'Sharing your location',
            backgroundMessage: 'Tap to open the app. Stop sharing in the app to end this.',
            requestPermissions: true,
            stale: false,
            distanceFilter: 10,
          },
          (location, error) => {
            if (error) {
              this._error.set(error.message ?? 'Background location error.');
              return;
            }
            if (!location) return;
            this._error.set(null);
            this._position.set({
              lat: location.latitude,
              lng: location.longitude,
              accuracy: location.accuracy,
              heading: location.bearing ?? null,
              speed: location.speed ?? null,
              timestamp: location.time ?? Date.now(),
            });
          }
        );
      } catch (err: any) {
        this._error.set(err.message ?? 'Could not start background location.');
        this._isWatching.set(false);
      }
      return;
    }

    if (!('geolocation' in navigator)) {
      this._error.set('Geolocation is not supported by this browser.');
      return;
    }
    this._isWatching.set(true);
    this.webWatchId = navigator.geolocation.watchPosition(
      (pos) => {
        this._error.set(null);
        this._position.set({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          heading: pos.coords.heading,
          speed: pos.coords.speed,
          timestamp: pos.timestamp,
        });
      },
      (err) => {
        this._error.set(err.message);
      },
      {
        enableHighAccuracy: false,
        maximumAge: 15000,
        timeout: 20000,
      }
    );
  }

  async stopWatching(): Promise<void> {
    if (this.nativeWatcherId !== null) {
      try {
        await BackgroundGeolocation.removeWatcher({ id: this.nativeWatcherId });
      } catch {
        // best-effort
      }
      this.nativeWatcherId = null;
    }
    if (this.webWatchId !== null) {
      navigator.geolocation.clearWatch(this.webWatchId);
      this.webWatchId = null;
    }
    this._isWatching.set(false);
  }

  getCurrentPosition(): Promise<GeoPosition> {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (pos) =>
          resolve({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
            heading: pos.coords.heading,
            speed: pos.coords.speed,
            timestamp: pos.timestamp,
          }),
        (err) => reject(err),
        { enableHighAccuracy: false, maximumAge: 60000, timeout: 20000 }
      );
    });
  }

  setError(message: string): void {
    this._error.set(message);
  }
}
