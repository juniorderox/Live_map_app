import { Injectable } from '@angular/core';
import { KeepAwake } from '@capacitor-community/keep-awake';

/**
 * Keeps the device screen from dimming/locking while the app is open.
 * Works on native (Android's FLAG_KEEP_SCREEN_ON) and on the web (the
 * Screen Wake Lock API, where supported — mainly Chrome-based browsers;
 * it silently no-ops on browsers that don't support it, rather than
 * throwing).
 */
@Injectable({ providedIn: 'root' })
export class ScreenWakeService {
  private enabled = false;

  constructor() {
    // The Wake Lock API (used on web) is auto-released by the browser
    // whenever the tab is hidden — reacquire it when it becomes visible
    // again so "keep the screen on" survives switching tabs and back.
    // Native Android doesn't need this: its screen-on flag only applies
    // while the app is actually in the foreground anyway.
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && this.enabled) {
        KeepAwake.keepAwake().catch(() => {});
      }
    });
  }

  async enable(): Promise<void> {
    if (this.enabled) return;
    try {
      await KeepAwake.keepAwake();
      this.enabled = true;
    } catch {
      // Not supported on this platform/browser — fine, just a no-op.
    }
  }

  async disable(): Promise<void> {
    if (!this.enabled) return;
    try {
      await KeepAwake.allowSleep();
    } catch {
      // Best-effort.
    } finally {
      this.enabled = false;
    }
  }
}
