package com.livemap.user;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
