import { Component, input, signal, computed, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GoogleMapsModule } from '@angular/google-maps';
import { TrackedEntity, HistoryPoint } from '../../services/live-tracking.service';

interface TrailSegment {
  path: google.maps.LatLngLiteral[];
  offline: boolean;
}

@Component({
  selector: 'app-tracker-map',
  standalone: true,
  imports: [CommonModule, GoogleMapsModule],
  template: `
    <google-map height="600px" width="100%" [center]="center()" [zoom]="zoom()" [options]="mapOptions">
      @for (segment of trailSegments(); track $index) {
        <map-polyline
          [path]="segment.path"
          [options]="{
            strokeColor: segment.offline ? '#eab308' : '#2563eb',
            strokeOpacity: 0.8,
            strokeWeight: segment.offline ? 4 : 3
          }"
        />
      }
      @for (tracker of trackers(); track tracker.id) {
        <map-marker
          [position]="markerPosition(tracker)"
          [title]="markerTitle(tracker)"
          [options]="{ icon: markerIcon(tracker) }"
        />
      }
    </google-map>
    @if (hasOfflineSegment()) {
      <p class="trail-legend">
        <span class="swatch offline"></span> traveled while offline
        <span class="swatch online"></span> traveled while online
      </p>
    }
  `,
  styles: [`
    .trail-legend { font-size: 0.75rem; color: #666; margin: 0.5rem 0 0; display: flex; align-items: center; gap: 0.4rem; }
    .swatch { width: 16px; height: 3px; display: inline-block; border-radius: 2px; }
    .swatch.offline { background: #eab308; }
    .swatch.online { background: #2563eb; margin-left: 0.75rem; }
  `],
})
export class TrackerMapComponent implements OnInit, OnDestroy {
  // Signal-based inputs so the `center` computed() below correctly
  // re-derives whenever these change (plain @Input() properties are not
  // signals and won't trigger computed() re-evaluation).
  trackers = input<TrackedEntity[]>([]);
  /** When set (e.g. from a "Center on me" button), overrides auto-centering on the first tracker. */
  manualCenter = input<google.maps.LatLngLiteral | null>(null);
  /** Breadcrumb trail points for whichever single user is currently selected, if any. */
  historyPoints = input<HistoryPoint[]>([]);

  protected readonly zoom = signal(13);
  protected readonly center = computed<google.maps.LatLngLiteral>(() => {
    const manual = this.manualCenter();
    if (manual) return manual;
    const first = this.trackers()[0];
    return first ? { lat: first.lat, lng: first.lng } : { lat: 21.0285, lng: 105.8542 };
  });

  protected readonly mapOptions: google.maps.MapOptions = {
    disableDefaultUI: false,
    clickableIcons: false,
  };

  /** Groups consecutive points with the same online/offline status into separate polyline segments. */
  protected readonly trailSegments = computed<TrailSegment[]>(() => {
    const points = this.historyPoints();
    if (points.length < 2) return [];

    const segments: TrailSegment[] = [];
    let current: TrailSegment = { path: [{ lat: points[0].lat, lng: points[0].lng }], offline: points[0].offline };

    for (let i = 1; i < points.length; i++) {
      const p = points[i];
      // A segment's offline status reflects whether the *arriving* point was
      // recorded offline, so the transition moment renders in the new color.
      if (p.offline === current.offline) {
        current.path.push({ lat: p.lat, lng: p.lng });
      } else {
        // Include the boundary point in both segments so the lines connect
        // without a visible gap.
        current.path.push({ lat: p.lat, lng: p.lng });
        segments.push(current);
        current = { path: [{ lat: p.lat, lng: p.lng }], offline: p.offline };
      }
    }
    segments.push(current);
    return segments;
  });

  protected readonly hasOfflineSegment = computed(() => this.historyPoints().some((p) => p.offline));

  /** Toggles on an interval to drive the pulsing "live" animation on active markers. */
  private readonly pulseOn = signal(true);
  private pulseTimer: ReturnType<typeof setInterval> | null = null;

  // Smoothly animates each marker's rotation AND position toward its real
  // values instead of snapping instantly. Google Maps' Marker has no
  // built-in transition, so this interpolates both by hand every animation
  // frame — heading takes the shortest rotational path (e.g. 350° -> 10°
  // turns +20°, not -340° the long way around), position uses simple linear
  // interpolation (fine for the short distances between consecutive GPS
  // fixes; not meant to follow roads, just smooth out the jump).
  private readonly displayedHeadings = new Map<string, number>();
  private readonly displayedPositions = new Map<string, google.maps.LatLngLiteral>();
  private readonly animTick = signal(0);
  private animFrameId: number | null = null;

  ngOnInit(): void {
    this.pulseTimer = setInterval(() => this.pulseOn.update((v) => !v), 700);
    this.animFrameId = requestAnimationFrame(() => this.animateMarkers());
  }

  ngOnDestroy(): void {
    if (this.pulseTimer) clearInterval(this.pulseTimer);
    if (this.animFrameId !== null) cancelAnimationFrame(this.animFrameId);
  }

  private animateMarkers(): void {
    let changed = false;
    for (const tracker of this.trackers()) {
      // Heading
      if (tracker.heading != null) {
        const target = tracker.heading;
        const current = this.displayedHeadings.get(tracker.id) ?? target;
        const diff = this.shortestAngleDiff(current, target);
        if (Math.abs(diff) > 0.5) {
          this.displayedHeadings.set(tracker.id, this.normalizeAngle(current + diff * 0.15));
          changed = true;
        } else if (current !== target) {
          this.displayedHeadings.set(tracker.id, target);
          changed = true;
        }
      }

      // Position
      const targetPos: google.maps.LatLngLiteral = { lat: tracker.lat, lng: tracker.lng };
      const currentPos = this.displayedPositions.get(tracker.id) ?? targetPos;
      const latDiff = targetPos.lat - currentPos.lat;
      const lngDiff = targetPos.lng - currentPos.lng;
      // ~0.0000005° is roughly 5cm — close enough to just snap the last bit
      // rather than asymptotically approach forever.
      if (Math.abs(latDiff) > 0.0000005 || Math.abs(lngDiff) > 0.0000005) {
        this.displayedPositions.set(tracker.id, {
          lat: currentPos.lat + latDiff * 0.15,
          lng: currentPos.lng + lngDiff * 0.15,
        });
        changed = true;
      } else if (currentPos.lat !== targetPos.lat || currentPos.lng !== targetPos.lng) {
        this.displayedPositions.set(tracker.id, targetPos);
        changed = true;
      }
    }
    if (changed) this.animTick.update((v) => v + 1);
    this.animFrameId = requestAnimationFrame(() => this.animateMarkers());
  }

  /** Shortest signed angular difference from `from` to `to`, in the range [-180, 180]. */
  private shortestAngleDiff(from: number, to: number): number {
    let diff = (to - from) % 360;
    if (diff > 180) diff -= 360;
    if (diff < -180) diff += 360;
    return diff;
  }

  private normalizeAngle(angle: number): number {
    return ((angle % 360) + 360) % 360;
  }

  protected markerPosition(tracker: TrackedEntity): google.maps.LatLngLiteral {
    this.animTick(); // read so this recomputes every animation frame
    return this.displayedPositions.get(tracker.id) ?? { lat: tracker.lat, lng: tracker.lng };
  }

  protected markerTitle(tracker: TrackedEntity): string {
    if (tracker.online) return tracker.label;
    return `${tracker.label} — last seen ${this.timeAgo(tracker.updatedAt)}`;
  }

  protected markerIcon(tracker: TrackedEntity): google.maps.Symbol {
    this.animTick(); // read so this recomputes every animation frame
    const isOnline = tracker.online;
    const pulsing = isOnline && this.pulseOn();
    const hue = this.hueForUid(tracker.id);
    const displayedHeading = this.displayedHeadings.get(tracker.id) ?? tracker.heading ?? 0;
    return {
      path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
      rotation: displayedHeading,
      scale: isOnline ? (pulsing ? 6.5 : 5) : 4,
      fillColor: isOnline ? `hsl(${hue}, 75%, 45%)` : `hsl(${hue}, 25%, 70%)`,
      fillOpacity: isOnline ? 1 : 0.6,
      strokeColor: isOnline ? `hsl(${hue}, 75%, 25%)` : `hsl(${hue}, 20%, 45%)`,
      strokeWeight: 1,
    };
  }

  /** Deterministic hue (0-359) from a uid, so each user always gets the same color. */
  private hueForUid(uid: string): number {
    let hash = 0;
    for (let i = 0; i < uid.length; i++) {
      hash = uid.charCodeAt(i) + ((hash << 5) - hash);
    }
    return Math.abs(hash) % 360;
  }

  private timeAgo(timestamp: number): string {
    const diffMs = Date.now() - timestamp;
    const mins = Math.floor(diffMs / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  }
}
