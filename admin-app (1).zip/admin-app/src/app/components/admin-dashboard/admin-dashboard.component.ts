import { Component, inject, signal, computed, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { AdminService } from '../../services/admin.service';
import { LiveTrackingService } from '../../services/live-tracking.service';
import { GeocodingService } from '../../services/geocoding.service';
import { TrackerMapComponent } from '../tracker-map/tracker-map.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, TrackerMapComponent],
  template: `
    <div class="dashboard">
      <header>
        <h1>Admin dashboard</h1>
        <button (click)="auth.logout()">Log out</button>
      </header>

      <section class="create-user">
        <h2>Add a user</h2>
        <form (ngSubmit)="createUser()">
          <input type="text" placeholder="Name / label" [(ngModel)]="newLabel" name="label" required />
          <input type="email" placeholder="Email" [(ngModel)]="newEmail" name="email" required />
          <input type="password" placeholder="Password (min 6 chars)" [(ngModel)]="newPassword" name="password" required minlength="6" />
          <button type="submit" [disabled]="creating()">
            {{ creating() ? 'Creating...' : 'Create user' }}
          </button>
        </form>
        @if (createError()) {
          <div class="error-banner">{{ createError() }}</div>
        }
        @if (createSuccess()) {
          <div class="success-banner">{{ createSuccess() }}</div>
        }
      </section>

      <section class="user-list">
        <h2>Your users ({{ admin.myUsers().length }})</h2>

        @if (admin.myUsers().length > 0) {
          <input
            type="text"
            class="search"
            placeholder="Search by name or email..."
            [ngModel]="searchTerm()"
            (ngModelChange)="searchTerm.set($event)"
          />
        }

        @if (admin.myUsers().length === 0) {
          <p class="empty">No users yet — add one above.</p>
        } @else if (filteredUsers().length === 0) {
          <p class="empty">No users match "{{ searchTerm() }}".</p>
        } @else {
          <ul>
            @for (u of filteredUsers(); track u.uid) {
              <li [class.selected]="selectedUid() === u.uid">
                <span
                  class="row-main"
                  [class.clickable]="hasEntity(u.uid)"
                  (click)="selectUser(u.uid)"
                >
                  <span class="color-dot" [style.background]="colorForUid(u.uid)"></span>
                  {{ u.label }} <span class="email">({{ u.email }})</span>
                  @if (isLive(u.uid)) {
                    <span class="live-badge">live</span>
                    @if (speedFor(u.uid); as speed) {
                      <span class="speed">{{ speed }}</span>
                    }
                  }
                </span>
                <button class="remove-btn" (click)="removeUser(u.uid, u.label)" [disabled]="removingUid() === u.uid">
                  {{ removingUid() === u.uid ? '...' : 'Remove' }}
                </button>
              </li>
            }
          </ul>
          <p class="hint">Each user has their own marker color, shown as the dot next to their name. Click a user to jump the map to them.</p>
        }

        @if (removeError()) {
          <div class="error-banner">{{ removeError() }}</div>
        }
      </section>

      <section class="map-section">
        <div class="map-header">
          <h2>Live map</h2>
          @if (selectedUid() && tracking.historyPoints().length > 0) {
            <button class="clear-route-btn" (click)="clearRoute()" [disabled]="clearingRoute()">
              {{ clearingRoute() ? 'Clearing...' : 'Clear route' }}
            </button>
          }
        </div>
        @if (selectedUid() && selectedAddress()) {
          <p class="address">📍 {{ selectedAddress() }}</p>
        }
        @if (clearError()) {
          <div class="error-banner">{{ clearError() }}</div>
        }
        <app-tracker-map [trackers]="trackerList()" [manualCenter]="selectedCenter()" [historyPoints]="tracking.historyPoints()" />
      </section>
    </div>

    @if (recentOfflineToasts().length > 0) {
      <div class="toast-stack">
        @for (t of recentOfflineToasts(); track t.at) {
          <div class="toast">{{ t.label }} stopped sharing their location</div>
        }
      </div>
    }
  `,
  styles: [`
    .dashboard { max-width: 960px; margin: 0 auto; padding: 1.5rem; font-family: system-ui, sans-serif; display: flex; flex-direction: column; gap: 1.5rem; }
    header { display: flex; justify-content: space-between; align-items: center; }
    h1 { font-size: 1.25rem; margin: 0; }
    h2 { font-size: 1rem; margin: 0 0 0.75rem; }
    form { display: flex; gap: 0.5rem; flex-wrap: wrap; }
    input { padding: 0.5rem; border: 1px solid #ccc; border-radius: 6px; font-size: 0.9rem; flex: 1; min-width: 140px; }
    input.search { width: 100%; margin-bottom: 0.75rem; flex: none; }
    button { padding: 0.5rem 1rem; border-radius: 6px; border: 1px solid #ccc; background: #fff; cursor: pointer; }
    form button[type="submit"] { background: #2563eb; color: #fff; border-color: #2563eb; }
    form button:disabled { opacity: 0.6; cursor: default; }
    ul { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 0.4rem; }
    li { display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; font-size: 0.9rem; padding: 0.4rem 0.6rem; border-radius: 6px; }
    li.selected { background: #dbeafe; }
    .row-main { display: flex; align-items: center; gap: 0.5rem; flex: 1; min-width: 0; }
    .row-main.clickable { cursor: pointer; }
    .row-main.clickable:hover { text-decoration: underline; }
    .color-dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; flex-shrink: 0; }
    .email { color: #888; font-size: 0.8rem; }
    .live-badge {
      font-size: 0.65rem;
      font-weight: 700;
      color: #16a34a;
      text-transform: uppercase;
      letter-spacing: 0.03em;
      border: 1px solid #16a34a;
      border-radius: 4px;
      padding: 0.1rem 0.35rem;
    }
    .speed { font-size: 0.75rem; color: #666; }
    .remove-btn { font-size: 0.75rem; padding: 0.3rem 0.6rem; color: #991b1b; border-color: #fca5a5; flex-shrink: 0; }
    .remove-btn:disabled { opacity: 0.5; }
    .empty { color: #888; font-size: 0.9rem; }
    .hint { color: #888; font-size: 0.8rem; margin: 0.5rem 0 0; }
    .address { font-size: 0.85rem; color: #444; margin: 0 0 0.5rem; }
    .map-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; }
    .map-header h2 { margin: 0; }
    .clear-route-btn { font-size: 0.8rem; color: #991b1b; border-color: #fca5a5; }
    .clear-route-btn:disabled { opacity: 0.5; }
    .error-banner { background: #fee2e2; color: #991b1b; padding: 0.5rem 0.75rem; border-radius: 6px; font-size: 0.85rem; margin-top: 0.5rem; }
    .success-banner { background: #dcfce7; color: #166534; padding: 0.5rem 0.75rem; border-radius: 6px; font-size: 0.85rem; margin-top: 0.5rem; }
    .toast-stack {
      position: fixed;
      top: 1rem;
      right: 1rem;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      z-index: 1000;
    }
    .toast {
      background: #1f2937;
      color: #fff;
      padding: 0.6rem 1rem;
      border-radius: 8px;
      font-size: 0.85rem;
      font-family: system-ui, sans-serif;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
  `],
})
export class AdminDashboardComponent implements OnInit, OnDestroy {
  protected auth = inject(AuthService);
  protected admin = inject(AdminService);
  protected tracking = inject(LiveTrackingService);
  protected geocoding = inject(GeocodingService);

  protected newLabel = '';
  protected newEmail = '';
  protected newPassword = '';
  protected readonly searchTerm = signal('');

  protected readonly creating = signal(false);
  protected readonly createError = signal<string | null>(null);
  protected readonly createSuccess = signal<string | null>(null);

  protected readonly removingUid = signal<string | null>(null);
  protected readonly removeError = signal<string | null>(null);

  protected readonly clearingRoute = signal(false);
  protected readonly clearError = signal<string | null>(null);

  /** uid of the user currently selected in the list, or null if none selected. */
  protected readonly selectedUid = signal<string | null>(null);
  protected readonly selectedAddress = signal<string | null>(null);

  protected readonly trackerList = computed(() => Array.from(this.tracking.entities().values()));

  protected readonly filteredUsers = computed(() => {
    const term = this.searchTerm().trim().toLowerCase();
    const users = this.admin.myUsers();
    if (!term) return users;
    return users.filter(
      (u) => u.label.toLowerCase().includes(term) || u.email.toLowerCase().includes(term)
    );
  });

  /** Live-updating center: follows the selected user's position as it changes in Firestore. */
  protected readonly selectedCenter = computed<google.maps.LatLngLiteral | null>(() => {
    const uid = this.selectedUid();
    if (!uid) return null;
    const entity = this.tracking.entities().get(uid);
    return entity ? { lat: entity.lat, lng: entity.lng } : null;
  });

  private readonly nowTick = signal(Date.now());
  private tickTimer: ReturnType<typeof setInterval> | null = null;

  protected readonly recentOfflineToasts = computed(() => {
    const now = this.nowTick();
    return this.tracking.offlineEvents().filter((e) => now - e.at < 6000);
  });

  ngOnInit(): void {
    const adminUid = this.auth.firebaseUser()?.uid;
    if (adminUid) {
      this.admin.subscribeToMyUsers(adminUid);
    }
    this.tickTimer = setInterval(() => this.nowTick.set(Date.now()), 1000);
  }

  ngOnDestroy(): void {
    this.admin.unsubscribe();
    this.tracking.unsubscribe();
    this.tracking.unsubscribeHistory();
    if (this.tickTimer) clearInterval(this.tickTimer);
  }

  isLive(uid: string): boolean {
    return this.tracking.entities().get(uid)?.online === true;
  }

  hasEntity(uid: string): boolean {
    return this.tracking.entities().has(uid);
  }

  /** Speed in km/h, formatted, or null if unknown/not moving. */
  speedFor(uid: string): string | null {
    const entity = this.tracking.entities().get(uid);
    if (!entity || entity.speed == null) return null;
    const kmh = entity.speed * 3.6; // m/s -> km/h
    if (kmh < 1) return null; // don't clutter the UI for essentially-stationary users
    return `${kmh.toFixed(0)} km/h`;
  }

  selectUser(uid: string): void {
    if (!this.hasEntity(uid)) return;
    const wasSelected = this.selectedUid() === uid;
    this.selectedUid.set(wasSelected ? null : uid);
    this.selectedAddress.set(null);

    if (wasSelected) {
      this.tracking.unsubscribeHistory();
    } else {
      this.tracking.subscribeToHistory(uid);
      const entity = this.tracking.entities().get(uid);
      if (entity) {
        this.geocoding.reverseGeocode(entity.lat, entity.lng).then((address) => {
          // Only apply if this is still the active selection (avoids a race
          // if the admin clicks around between users quickly).
          if (this.selectedUid() === uid) {
            this.selectedAddress.set(address);
          }
        });
      }
    }
  }

  colorForUid(uid: string): string {
    let hash = 0;
    for (let i = 0; i < uid.length; i++) {
      hash = uid.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hue = Math.abs(hash) % 360;
    return `hsl(${hue}, 75%, 45%)`;
  }

  async clearRoute(): Promise<void> {
    const uid = this.selectedUid();
    if (!uid) return;
    if (!confirm('Delete this user\'s entire route history? This cannot be undone.')) return;

    this.clearError.set(null);
    this.clearingRoute.set(true);
    try {
      await this.tracking.clearHistory(uid);
    } catch (err: any) {
      this.clearError.set(err.message ?? 'Could not clear the route.');
    } finally {
      this.clearingRoute.set(false);
    }
  }

  async removeUser(uid: string, label: string): Promise<void> {
    if (!confirm(`Remove ${label}? They'll lose access to the app immediately.`)) return;
    this.removeError.set(null);
    this.removingUid.set(uid);
    try {
      await this.admin.removeUser(uid);
      if (this.selectedUid() === uid) {
        this.selectedUid.set(null);
        this.selectedAddress.set(null);
        this.tracking.unsubscribeHistory();
      }
    } catch (err: any) {
      this.removeError.set(err.message ?? 'Could not remove user.');
    } finally {
      this.removingUid.set(null);
    }
  }

  async createUser(): Promise<void> {
    this.createError.set(null);
    this.createSuccess.set(null);
    this.creating.set(true);
    try {
      await this.admin.createUserAccount(this.newEmail, this.newPassword, this.newLabel);
      this.createSuccess.set(`Created account for ${this.newLabel}.`);
      this.newLabel = '';
      this.newEmail = '';
      this.newPassword = '';
    } catch (err: any) {
      this.createError.set(err.message ?? 'Could not create user.');
    } finally {
      this.creating.set(false);
    }
  }
}
