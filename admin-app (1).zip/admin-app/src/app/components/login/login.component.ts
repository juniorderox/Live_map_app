import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="login-shell">
      <h1>Admin Log in</h1>
      <p class="hint">Your account is created for you — there's no self-signup.</p>

      <form (ngSubmit)="submit()">
        <label>
          Email
          <input type="email" name="email" [(ngModel)]="email" required />
        </label>
        <label>
          Password
          <input type="password" name="password" [(ngModel)]="password" required minlength="6" />
        </label>
        <button type="submit" [disabled]="submitting()">
          {{ submitting() ? 'Logging in...' : 'Log in' }}
        </button>
      </form>

      @if (error()) {
        <div class="error-banner">{{ error() }}</div>
      }
    </div>
  `,
  styles: [`
    .login-shell { max-width: 320px; margin: 4rem auto; display: flex; flex-direction: column; gap: 1rem; font-family: system-ui, sans-serif; }
    h1 { font-size: 1.25rem; margin: 0; text-align: center; }
    .hint { font-size: 0.85rem; color: #666; text-align: center; margin: 0; }
    form { display: flex; flex-direction: column; gap: 0.75rem; }
    label { display: flex; flex-direction: column; gap: 0.25rem; font-size: 0.85rem; color: #444; }
    input { padding: 0.5rem; border: 1px solid #ccc; border-radius: 6px; font-size: 1rem; }
    button[type="submit"] { padding: 0.6rem; border-radius: 6px; border: none; background: #2563eb; color: #fff; cursor: pointer; }
    button[type="submit"]:disabled { opacity: 0.6; cursor: default; }
    .error-banner { background: #fee2e2; color: #991b1b; padding: 0.5rem 0.75rem; border-radius: 6px; font-size: 0.85rem; }
  `],
})
export class LoginComponent {
  private auth = inject(AuthService);

  protected readonly submitting = signal(false);
  protected readonly error = signal<string | null>(null);

  protected email = '';
  protected password = '';

  async submit(): Promise<void> {
    this.error.set(null);
    this.submitting.set(true);
    try {
      await this.auth.login(this.email, this.password);
    } catch (err: any) {
      this.error.set(err.message ?? 'Something went wrong.');
    } finally {
      this.submitting.set(false);
    }
  }
}
