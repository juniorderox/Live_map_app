import { Component, inject } from '@angular/core';
import { AuthService } from './services/auth.service';
import { LoginComponent } from './components/login/login.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [LoginComponent, AdminDashboardComponent],
  template: `
    @if (auth.loading()) {
      <p class="loading">Loading...</p>
    } @else if (!auth.firebaseUser()) {
      <app-login />
    } @else if (auth.profile()?.role === 'admin') {
      <app-admin-dashboard />
    } @else {
      <p class="loading">
        This account isn't an admin. Log in with an admin account, or use
        the user app instead.
        <br /><br />
        <button (click)="auth.logout()">Log out</button>
      </p>
    }
  `,
  styles: [`
    .loading { text-align: center; margin-top: 4rem; font-family: system-ui, sans-serif; color: #666; }
    button { padding: 0.5rem 1rem; border-radius: 6px; border: 1px solid #ccc; background: #fff; cursor: pointer; }
  `],
})
export class AppComponent {
  protected auth = inject(AuthService);
}
