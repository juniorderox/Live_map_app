import { ApplicationConfig } from '@angular/core';
import { provideFirebaseApp, initializeApp, getApp } from '@angular/fire/app';
import {
  provideFirestore,
  initializeFirestore,
  persistentLocalCache,
  persistentSingleTabManager,
} from '@angular/fire/firestore';
import { provideAuth, getAuth } from '@angular/fire/auth';
import { environment } from '../environments/environment';

export const appConfig: ApplicationConfig = {
  providers: [
    provideFirebaseApp(() => initializeApp(environment.firebase)),
    provideFirestore(() =>
      // Enables offline persistence: while offline, position writes queue
      // locally (in IndexedDB) and automatically sync once back online.
      // GPS itself never needed the network — this closes the other half
      // of the gap, so no location updates get silently dropped offline.
      initializeFirestore(getApp(), {
        localCache: persistentLocalCache({
          tabManager: persistentSingleTabManager(undefined),
        }),
      })
    ),
    provideAuth(() => getAuth()),
  ],
};
