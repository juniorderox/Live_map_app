import { Injectable, inject, signal } from '@angular/core';
import { initializeApp, deleteApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { Auth } from '@angular/fire/auth';
import {
  Firestore,
  doc,
  setDoc,
  deleteDoc,
  serverTimestamp,
  collection,
  query,
  where,
  onSnapshot,
  Unsubscribe,
} from '@angular/fire/firestore';
import { environment } from '../../environments/environment';
import { LiveTrackingService } from './live-tracking.service';

export interface ManagedUser {
  uid: string;
  email: string;
  label: string;
}

@Injectable({ providedIn: 'root' })
export class AdminService {
  private firestore = inject(Firestore);
  private auth = inject(Auth);
  private tracking = inject(LiveTrackingService);

  readonly myUsers = signal<ManagedUser[]>([]);
  private unsub: Unsubscribe | null = null;
  private lastSubscribedUids: string[] = [];

  /**
   * Creates a new user account (email/password set by the admin) without
   * disturbing the admin's own signed-in session. Firebase's client SDK
   * normally signs you in as whichever account you just created, so this
   * spins up a throwaway secondary app instance just for the signup call,
   * then tears it down.
   */
  async createUserAccount(email: string, password: string, label: string): Promise<void> {
    const adminUid = this.auth.currentUser?.uid;
    if (!adminUid) throw new Error('You must be signed in as an admin to create users.');

    const secondaryApp = initializeApp(environment.firebase, 'secondary-' + Date.now());
    const secondaryAuth = getAuth(secondaryApp);
    try {
      const cred = await createUserWithEmailAndPassword(secondaryAuth, email, password);
      await setDoc(doc(this.firestore, 'users', cred.user.uid), {
        email,
        label,
        role: 'user',
        ownerAdminId: adminUid,
        createdAt: serverTimestamp(),
      });
    } finally {
      await signOut(secondaryAuth);
      await deleteApp(secondaryApp);
    }
  }

  /**
   * Live list of every user this admin has created, kept in sync.
   * Also re-subscribes the live tracking map to exactly these uids whenever
   * the SET of uids actually changes — done here directly (not via an
   * Angular effect()) so it isn't subject to the "no signal writes inside
   * effects" restriction. Only re-subscribes on a genuine change (not every
   * snapshot fire) to avoid flickering the map by tearing down and rebuilding
   * the tracker listener when nothing actually changed.
   */
  subscribeToMyUsers(adminUid: string): void {
    if (this.unsub) return;
    const q = query(
      collection(this.firestore, 'users'),
      where('role', '==', 'user'),
      where('ownerAdminId', '==', adminUid)
    );
    this.unsub = onSnapshot(q, (snap) => {
      const users = snap.docs.map((d) => ({
        uid: d.id,
        email: d.data()['email'],
        label: d.data()['label'] ?? d.data()['email'],
      }));
      this.myUsers.set(users);

      const uids = users.map((u) => u.uid).sort();
      const changed =
        uids.length !== this.lastSubscribedUids.length ||
        uids.some((id, i) => id !== this.lastSubscribedUids[i]);
      if (changed) {
        this.lastSubscribedUids = uids;
        this.tracking.subscribeToUids(uids);
      }
    });
  }

  unsubscribe(): void {
    this.unsub?.();
    this.unsub = null;
    this.lastSubscribedUids = [];
    this.tracking.unsubscribe();
  }

  /**
   * Removes a user's profile, revoking their access to the app (they'll see
   * "not set up as a user" on next login) and hiding them from your
   * dashboard. This does NOT delete their underlying Firebase Auth login —
   * that requires the Firebase Console (Authentication tab) or a backend
   * Admin SDK call, since the client SDK can't delete other users' accounts.
   */
  async removeUser(uid: string): Promise<void> {
    await deleteDoc(doc(this.firestore, 'users', uid));
  }
}
