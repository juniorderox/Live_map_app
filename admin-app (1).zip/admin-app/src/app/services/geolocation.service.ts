import { Injectable, signal, computed } from '@angular/core';

export interface GeoPosition {
  lat: number;
  lng: number;
  accuracy: number;
  heading: number | null;
  speed: number | null;
  timestamp: number;
}

/**
 * Wraps the browser Geolocation API in a signal-based service.
 * Call startWatching() once (e.g. from a driver/tracker view) and
 * read position() anywhere it's needed.
 */
@Injectable({ providedIn: 'root' })
export class GeolocationService {
  private readonly _position = signal<GeoPosition | null>(null);
  private readonly _error = signal<string | null>(null);
  private readonly _isWatching = signal(false);
  private watchId: number | null = null;

  readonly position = this._position.asReadonly();
  readonly error = this._error.asReadonly();
  readonly isWatching = this._isWatching.asReadonly();
  readonly hasFix = computed(() => this._position() !== null);

  // --- Compass heading (device orientation) ---
  // GPS-derived heading (position.coords.heading) only updates while the
  // device is physically moving. Compass heading updates even while
  // stationary, so the marker arrow reflects which way the phone is
  // pointing at all times. We prefer compass heading when available.
  private readonly _compassHeading = signal<number | null>(null);
  readonly compassHeading = this._compassHeading.asReadonly();
  readonly effectiveHeading = computed(
    () => this._compassHeading() ?? this._position()?.heading ?? null
  );

  private readonly orientationHandler = (event: DeviceOrientationEvent) => {
    const anyEvent = event as any;
    if (typeof anyEvent.webkitCompassHeading === 'number') {
      // iOS Safari gives a direct compass reading — most reliable.
      this._compassHeading.set(anyEvent.webkitCompassHeading);
    } else if (event.alpha !== null) {
      // Fallback for other browsers: alpha is rotation around the z-axis.
      this._compassHeading.set(360 - event.alpha);
    }
  };

  /**
   * iOS 13+ requires an explicit permission prompt for device orientation,
   * and it must be triggered by a user gesture (e.g. a button click).
   * Returns true if compass access is available (either granted, or not
   * needed on this browser/OS).
   */
  async requestCompassPermission(): Promise<boolean> {
    const DOE: any = (window as any).DeviceOrientationEvent;
    if (DOE && typeof DOE.requestPermission === 'function') {
      try {
        const result = await DOE.requestPermission();
        return result === 'granted';
      } catch {
        return false;
      }
    }
    return true; // Not iOS 13+ — no permission prompt needed.
  }

  startCompass(): void {
    const win = window as any;
    if ('ondeviceorientationabsolute' in window) {
      win.addEventListener('deviceorientationabsolute', this.orientationHandler, true);
    } else if ('ondeviceorientation' in window) {
      win.addEventListener('deviceorientation', this.orientationHandler, true);
    }
  }

  stopCompass(): void {
    const win = window as any;
    win.removeEventListener('deviceorientationabsolute', this.orientationHandler, true);
    win.removeEventListener('deviceorientation', this.orientationHandler, true);
    this._compassHeading.set(null);
  }

  startWatching(): void {
    if (this.watchId !== null) return; // already watching

    if (!('geolocation' in navigator)) {
      this._error.set('Geolocation is not supported by this browser.');
      return;
    }

    this._isWatching.set(true);
    this.watchId = navigator.geolocation.watchPosition(
      (pos) => {
        this._error.set(null);
        this._position.set({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          heading: pos.coords.heading,
          speed: pos.coords.speed,
          timestamp: pos.timestamp,
        });
      },
      (err) => {
        this._error.set(err.message);
      },
      {
        enableHighAccuracy: false,
        maximumAge: 15000,
        timeout: 20000,
      }
    );
  }

  stopWatching(): void {
    if (this.watchId !== null) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
    this._isWatching.set(false);
  }

  /** One-off read, useful for "center map on me" buttons. */
  getCurrentPosition(): Promise<GeoPosition> {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (pos) =>
          resolve({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
            heading: pos.coords.heading,
            speed: pos.coords.speed,
            timestamp: pos.timestamp,
          }),
        (err) => reject(err),
        { enableHighAccuracy: false, maximumAge: 60000, timeout: 20000 }
      );
    });
  }

  /** Lets callers (e.g. a "Center on me" button) surface a geolocation error to the UI. */
  setError(message: string): void {
    this._error.set(message);
  }
}
