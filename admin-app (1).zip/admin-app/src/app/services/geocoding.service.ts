import { Injectable } from '@angular/core';

/**
 * Wraps google.maps.Geocoder for turning coordinates into a readable
 * address. Caches by rounded coordinate so panning/small GPS jitter
 * doesn't trigger repeated API calls (Geocoding API is billed per call).
 */
@Injectable({ providedIn: 'root' })
export class GeocodingService {
  private geocoder: google.maps.Geocoder | null = null;
  private readonly cache = new Map<string, string>();

  private getGeocoder(): google.maps.Geocoder {
    if (!this.geocoder) {
      this.geocoder = new google.maps.Geocoder();
    }
    return this.geocoder;
  }

  private cacheKey(lat: number, lng: number): string {
    // Round to ~11m precision — good enough to dedupe repeat calls for the
    // same spot without needing exact float matches.
    return `${lat.toFixed(4)},${lng.toFixed(4)}`;
  }

  async reverseGeocode(lat: number, lng: number): Promise<string> {
    const key = this.cacheKey(lat, lng);
    const cached = this.cache.get(key);
    if (cached) return cached;

    try {
      const result = await this.getGeocoder().geocode({ location: { lat, lng } });
      const address = result.results[0]?.formatted_address ?? `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
      this.cache.set(key, address);
      return address;
    } catch {
      // Fall back to raw coordinates if geocoding fails (quota, network, etc).
      return `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    }
  }
}
