export const environment = {
  production: true,
  googleMapsApiKey: 'AIzaSyD1Fn_qIe7JC8NMXtN40uaMtLgiYEdmBEo',
  firebase: {
    apiKey: 'AIzaSyD1Fn_qIe7JC8NMXtN40uaMtLgiYEdmBEo',
    authDomain: 'livemap2.firebaseapp.com',
    projectId: 'livemap2',
    storageBucket: 'livemap2.firebasestorage.app',
    messagingSenderId: '776298811006',
    appId: '1:776298811006:web:59eb7e5f6b070e3406522f',
  },
};
