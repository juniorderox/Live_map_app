# Live Map — Admin App

This is the **admin app**. Admins sign up here, create user accounts here,
and see all their users' live locations on one map here. Users never see
this app — they get their own separate **User App**, using an account you
create for them.

Both apps share one Firebase project. Set up Firebase once (below), then
copy the same `environment.ts` values and Maps API key into the User App too.

## How it works

1. **Firebase Authentication (email/password)** handles admin login/signup.
2. Signing up here creates a `users/{uid}` doc with `role: 'admin'`.
3. **"Add a user"** on the dashboard creates a *new* Firebase Auth account
   (email + password you choose) plus a `users/{uid}` doc with
   `role: 'user'` and `ownerAdminId` set to your uid. This uses a throwaway
   secondary Firebase app instance internally so creating the user doesn't
   log you out of your own admin session.
4. The dashboard subscribes to `trackers/{uid}` for exactly the uids of
   users you created — nothing else, nobody else's data.

## Quick start

```bash
cd admin-app
npm install
```

Do the Firebase + Google Maps setup below, paste the keys into
`src/environments/environment.ts` and `src/index.html`, then:

```bash
npm start
```

Open http://localhost:4200 (or a different port if the User App is already
running on 4200 — see note below).

**First-time flow:**
1. Log in with the admin account created for you via the Super Admin App
   (see that project's README) — there's no self-signup here anymore.
2. On the dashboard, use **"Add a user"** — set their name, email, password.
3. Give that email/password to the person — they log in at the **User App**'s
   URL, not this one.
4. Once they click "Share my location" there, their marker appears here live.

> Running both apps locally at once? `ng serve` defaults to port 4200 for
> both. Run this one on a different port: `ng serve --port 4300`.

## 1. Get a Google Maps API key

1. Go to https://console.cloud.google.com — create/select a project.
2. APIs & Services → Library → search "Maps JavaScript API" → Enable.
3. APIs & Services → Credentials → Create Credentials → API key.
4. Paste it into `src/environments/environment.ts` (`googleMapsApiKey`) and
   the `<script src="...key=...">` tag in `src/index.html`.
5. **Use this same key in the User App too.**

## 2. Set up Firebase (shared by both apps)

1. Create a project at https://console.firebase.google.com
2. **Build → Authentication → Get started → Email/Password → Enable.**
3. **Build → Firestore Database → Create database** (Standard edition, test
   mode for now).
4. Project settings → Your apps → register a web app → copy the
   `firebaseConfig` object into `src/environments/environment.ts`.
5. **Use this same `firebaseConfig` in the User App too** — both apps must
   point at the same Firebase project or they won't see each other's data.

## 3. Firestore security rules

Replace your entire ruleset with this (this version adds the `superadmins`
collection and closes an old hole where any signed-up user could
self-assign `role: 'admin'` — see the Super Admin App's README for why):

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    match /superadmins/{uid} {
      allow read: if request.auth != null && request.auth.uid == uid;
      // No client write access at all — only added manually via the
      // Firebase Console. This is intentional: there is no app feature,
      // anywhere, that can create this document.
    }

    match /users/{uid} {
      allow read: if request.auth != null &&
        (request.auth.uid == uid ||
         resource.data.ownerAdminId == request.auth.uid ||
         exists(/databases/$(database)/documents/superadmins/$(request.auth.uid)));

      allow create: if request.auth != null &&
        ((request.resource.data.role == 'admin' &&
          exists(/databases/$(database)/documents/superadmins/$(request.auth.uid))) ||
         (request.resource.data.role == 'user' &&
          request.resource.data.ownerAdminId == request.auth.uid));

      // An admin can remove a user profile they created; a super admin can
      // remove any user or admin profile.
      allow delete: if request.auth != null &&
        (resource.data.ownerAdminId == request.auth.uid ||
         exists(/databases/$(database)/documents/superadmins/$(request.auth.uid)));
    }

    match /trackers/{uid} {
      allow write: if request.auth != null && request.auth.uid == uid;

      allow read: if request.auth != null &&
        (request.auth.uid == uid ||
         get(/databases/$(database)/documents/users/$(uid)).data.ownerAdminId == request.auth.uid);

      match /history/{historyId} {
        allow create: if request.auth != null && request.auth.uid == uid;
        allow read: if request.auth != null &&
          (request.auth.uid == uid ||
           get(/databases/$(database)/documents/users/$(uid)).data.ownerAdminId == request.auth.uid);
        allow delete: if request.auth != null &&
          (request.auth.uid == uid ||
           get(/databases/$(database)/documents/users/$(uid)).data.ownerAdminId == request.auth.uid);
      }
    }
  }
}
```

Firebase Console → Firestore Database → Rules → paste → Publish.

## Notes / next steps

- **Admin accounts are created only via the Super Admin App**: this app has
  no self-signup — admins can only be created by whoever has a
  `superadmins/{uid}` doc in Firestore, set up manually via the Firebase
  Console. See the Super Admin App's README.
- **Deploying separately**: since these are independent Angular projects,
  you can deploy the Admin App and Super Admin App somewhere private (or
  just run them locally) and only publish the User App's URL to actual users.
- **Stale markers**: a "live" badge next to a user's name means the
  dashboard currently has a live snapshot for them; their marker stays at
  its last position on the map even after they stop sharing, until it
  updates again.
